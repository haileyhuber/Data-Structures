package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }

  // --- end used for testing -------------------------------------------

  
  // --- fill in these methods ------------------------------------------
  //
  // at the moment, they are stubs returning false 
  // or some appropriate "fake" value
  //
  // you make them work properly
  // add the meat of correct implementation logic to them

  // you MAY change the signatures if you wish...
  // make the take more or different parameters
  // have them return different types
  //
  // you may use recursive or iterative implementations

  
  public boolean containsNode(String s){ 
	
	  if(s.compareTo(this.data) == 0){
		  return true;
	  }
	  else if((s.compareTo(this.data) < 0) && left != null){
		  return left.containsNode(s);
	  }
	  else if((s.compareTo(this.data) > 0) && right != null){
		  return right.containsNode(s);
	  }
	  else{
		  return false;
	  }
}
  public boolean insertNode(String s){ 
	 
	  if(s.compareTo(this.data) == 0){
		  return false;
	  }
	  else{
		  //left
		if(s.compareTo(this.data) < 0){
			if(this.left == null){
				this.left = new BST_Node(s);
			}
			else{
				this.left.insertNode(s);
			}
		}
		//right
		else if(s.compareTo(this.data) > 0){
			if(this.right == null){
				this.right = new BST_Node(s);
			}
			else{
				this.right.insertNode(s);
			}
		}
		return true;
		}
		  
	  }

  public boolean removeNode(String s){ 
	  
	  if(this.containsNode(s) == true){
		  
		  //look left
		  if(s.compareTo(this.data) < 0){
			  if(this.left.data.compareTo(s) == 0){
				  //no chillins
				  if(this.left.left == null && this.left.right == null){
					  this.left = null;
				  }
				  //left kid
				  else if(this.left.left != null && this.left.right == null){
					  this.left = this.left.left;
				  }
				  //right kid
				  else if(this.left.left == null && this.left.right != null){
					  this.left = this.left.right;
				  }
				  //both kids
				  else {
					  this.left.data = this.left.right.findMin().data;
					  this.left.removeNode(this.left.right.findMin().data);
					  
				  }
			  }
			  else{
				  this.left.removeNode(s);
			  }
			  
		  }
		  //look right
		  if(s.compareTo(this.data) >= 0){//????????????????????
			  if(this.right.data.compareTo(s) == 0){
				  //no chillins
				  if(this.right.left == null && this.right.right == null){
					  this.right = null;
				  }
				  else if(this.right.left != null && this.right.right == null){
					  this.right = this.right.left;
				  }
				  else if(this.right.left == null && this.right.right != null){
					  this.right = this.right.right;
				  }
				  else {
					  this.right.data = this.right.right.findMin().data;
					  this.right.removeNode(this.right.right.findMin().data);
					  
				  }
			  }
			  else{
				  this.right.removeNode(s);
			  }
			  
		  }
		  
		return true;  
	  }
	  else{
		  return false;
	  }
	  
  }
  public BST_Node findMin(){ 
	  if(this.left == null){
		  return this;
	  }
	  else{
		  return this.left.findMin();
	  }
  }
  public BST_Node findMax(){ 
	  if(this.right == null){
		  return this;
	  }
	  else{
		  return this.right.findMax();
	  }
  }
  
  public int getHeight(){ 
	  int i = 0;
	  int j = 0;
	  if(this.left != null){
		  i = 1+this.left.getHeight();
	  }
	  if(this.right != null){
		  j = 1 + this.right.getHeight();
	  }
	  if(i > j){
		  return i;
	  }
	  else{
		  return j;
	  }
	  
	  
  }


  // --- end fill in these methods --------------------------------------


  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}

