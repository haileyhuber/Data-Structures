package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
  private EntryPair[] array; //load this array
  private int size;
  private static final int arraySize = 10000; //Everything in the array will initially 
                                              //be null. This is ok! Just build out 
                                              //from array[1]

  public MinBinHeap() {
    this.array = new EntryPair[arraySize];
    array[0] = new EntryPair(null, -100000); //0th will be unused for simplicity 
                                             //of child/parent computations...
                                             //the book/animation page both do this.
  }
    
  //Please do not remove or modify this method! Used to test your entire Heap.
  @Override
  public EntryPair[] getHeap() { 
    return this.array;
  }

@Override
public void insert(EntryPair entry) {
	EntryPair insertedNode = entry;
	int emptySpace = ++size;
	
	while(insertedNode.priority < array[emptySpace/2].priority){
		array[emptySpace] = array[emptySpace/2];
		emptySpace = (emptySpace/2);
	}
	array[emptySpace] = entry;
	
}

@Override
public void delMin() {
	if(size == 0){
		return;
		}
	
	array[1] = array[size];
	size--;
	
	//created bubbleDown method at the end to help reduce code in delMin() and build()
	bubbleDown(1);
	
		}

@Override
public EntryPair getMin() {
	if(array[1] == null){
		return null;
	}
	else{ return array[1];}
	}


@Override
public int size() {
	if(array[1] == null){
		return 0;
	}
	
	return size;
	
}

@Override
public void build(EntryPair[] entries) {
	
	for(int i=0; i < entries.length; i++){ //load all into array
	array[i+1] = entries[i]; 
	size++;
	}

	for(int k = size/2; k > 0; k--){ //send each value through bubbleDown() to get it sorted 
		
		bubbleDown(k);
	}
	
}

private void bubbleDown(int emptySpace){
	
	int childNode;
	EntryPair temporary = array[emptySpace];

	for( ; emptySpace*2 <= size; emptySpace = childNode){

		childNode = emptySpace*2;

		if(childNode != size && array[childNode + 1].priority < array[childNode].priority){
			childNode++;
		}
		
		if(array[childNode].priority < temporary.priority){
			array[emptySpace] = array[childNode];
		}
		else{
			break;
		}
	}
	
	array[emptySpace] = temporary;
}
}

//REFERENCED FROM MARK ALLEN WEISS TEXTBOOK, PAGES 231-233 (DATA STRUCTURES AND ALGORITHM ANALYSIS IN JAVA - 3RD EDITION) 