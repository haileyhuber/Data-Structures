package LinkedListA0;

public class LinkedListImpl implements LIST_Interface{
	Node root;//this will be the entry point to your linked list (the head)
	  
	  public LinkedListImpl(){//this constructor is needed for testing purposes. Please don't modify!
	    root=new Node(0); //Note that the root's data is not a true part of your data set!
	  }
	  
	  //implement all methods in interface, and include the getRoot method we made for testing purposes. Feel free to implement private helper methods!
	  
	  public Node getRoot(){ //leave this method as is, used by the grader to grab your linkedList easily.
	    return root;
	  }

	@Override
	public boolean insert(Node n, int index) {
		
		Node currNode = root;
		Node after;
		int counter = -1;
		
		while(counter<(index-1) && currNode.next != null){
			currNode = currNode.next;
			counter++;
		}
		
		if(counter+1 < index || index < 0){
			return false;
		}
			n.prev = currNode;
			after = currNode.next;
			currNode.next = n;
			n.next = after;
			
			if(n.next != null){
			(n.next).prev = n;
			}
			
			return true;
		
	}

	@Override
	public boolean remove(int index) {
		
		Node currNode = root;
		int counter = -1;
		
		while(counter<(index) && currNode.next != null){
			currNode = currNode.next;
			counter++;
		}
		
		if(counter+1 < index || index < 0){
			return false;
		}
		
		//remove currNode
		if(currNode.next != null){
			
			(currNode.next).prev = currNode.prev;
		
		}
		
		(currNode.prev).next = currNode.next;
		return true;
		
	}

	@Override
	public Node get(int index) {
		
		Node currNode = root;
		int counter = -1;
		
		while(counter<(index)){
			currNode = currNode.next;
			counter++;
		}
		
		return currNode;
		
	}

	@Override
	public int size() {
		
		Node currNode = root;
		int counter = -1;
		
	while(currNode.next != null){
		counter++;
		currNode = currNode.next;
		
	}
	return counter+1;
		
	}

	@Override
	public boolean isEmpty() {
		if(root.next == null){
			return true;
		}
		else{
		return false;
		}
	}

	@Override
	public void clear() {
		root.next = null;
		
	}
	}